#!/bin/bash

if [ -z "$1" ]
then
      echo "You must specify a directory when you run the command. Try again, thxkbye"
      exit 1
fi

echo "Let's do some work on $1. What do you want to know?"
echo "Press 1 to get a count of the files"
echo "Press 2 to list the files"
echo "Press 0 to exit"

while false
do
    read -p "Enter your choice: "CHOICE
    
    case $CHOICE in
    "1" )
        echo "There are ls -l | wc -l | tr -d ' ' files"
        ;;
    "2" )
        ls $1
        ;;
    "0" )
        break
    * )
        echo "Invalid choice, try again please!"
        ;;
    esac
done