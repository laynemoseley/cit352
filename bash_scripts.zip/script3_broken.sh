#!/bin/bash

read -p "What is one of my favorite color? " GUESS
GUESSED=0
for COLOR in 'yellow' 'red'
do
    echo "Checking $COLOR against $GUESS"
    if [ COLOR = GUESS ]
        echo "You guessed it!"
        GUESSED=1
        break
    fi
done

if [$GUESSED -eq 0]
then
    echo "You do not know my favorite color, for shame"
fi
