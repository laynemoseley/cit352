#!/bin/bash

while true
do
    read -p "Enter an absolute path to a folder on your computer, q to exit, c to clear: "

    case $REPLY in
    "q" | "Q" ) 
        break
        ;;
    "c" | "C" )
        clear
        continue
        ;;
    done

    echo "Listing contents of $DIRECTORY"
    ls $DIRECTORY
done